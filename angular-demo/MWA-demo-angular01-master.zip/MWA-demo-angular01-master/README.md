# MWA - Demo - Angular 01
This repo contains an Angular app with 6 components:
1. **Component1:** Using `@Intput` and Data Binding
2. **Component2:** Using `ViewEncapsulation`
3. **Component3:** Using `@Output` and custom `EventEmitter`
4. **Component4:** Two ways data binding
5. **Component5:** Using `ViewChild` and `ContentChild`
6. **Component6:** Component life-cycle hooks
